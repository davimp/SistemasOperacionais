#include <iostream>
#include <fstream>
//#include "arquivo.hpp"

#define MAXN 1000//000

using namespace std;

int bitmap[MAXN];
int FAT[MAXN];

int main(int argc, char *argv[]){

    //string nome_arq;
    fstream arq, f;
    arq.open("sistema.txt");//, ios::in);//, ios::in | ios::out);

    arq << "ALALALA" << endl;
    cout << "Aberto? " << arq.is_open() << endl;

    /*if(arq.fail()){
        cout << "erro";
        arq << "AAA\n";
    }
    else{
        cout << "deu certo";
    }
    arq << "BORA";*/
    /*
    if(argc < 2)
    {
        cout << "Uso: ./ep3 <nome do aqruivo>" << endl;//melhorar texto?
        exit(-1);
    }
    
    arq.open(argv[1]);*/
    //ios_base::std::arq.failbit;
    cout << arq.failbit << endl;
    arq.close();

    f.open("abc.txt");
    f << "ola";
    f.close();

    return 0;
}